package com.droidkit.actors.tasks;

/**
 * Exception about cancelling task
 *
 * @author Stepan Ex3NDR Korshakov (me@ex3ndr.com)
 */
public class AskCancelledException extends Exception {

}

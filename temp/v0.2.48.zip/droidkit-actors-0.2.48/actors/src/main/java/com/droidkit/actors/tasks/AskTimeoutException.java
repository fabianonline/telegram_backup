package com.droidkit.actors.tasks;

/**
 * Exception for Ask timeout
 *
 * @author Stepan Ex3NDR Korshakov (me@ex3ndr.com)
 */
public class AskTimeoutException extends Exception {
}
